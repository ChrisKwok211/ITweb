# Simple Resume/CV Template 1

A Pen created on CodePen.io. Original URL: [https://codepen.io/abnovels/pen/XWbxgzj](https://codepen.io/abnovels/pen/XWbxgzj).

